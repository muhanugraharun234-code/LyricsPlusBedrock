package com.lyricsplus.bedrock

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

data class LrcLine(val ms: Long, val text: String)

object LrcParser {
    private val ts = Regex("""\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?]""")
    private val offset = Regex("""\[offset:\s*([+-]?\d+)]""", RegexOption.IGNORE_CASE)

    fun parse(raw: String): List<LrcLine> {
        if (raw.isBlank()) return emptyList()
        val off = offset.find(raw)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        val out = ArrayList<LrcLine>()
        for (line in raw.lines()) {
            val stamps = ts.findAll(line).toList()
            if (stamps.isEmpty()) continue
            val text = line.substring(stamps.last().range.last + 1).trim()
            for (m in stamps) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = when (frac.length) { 0 -> 0L; 1 -> frac.toLong() * 100; 2 -> frac.toLong() * 10; else -> frac.toLong() }
                out += LrcLine((min * 60 + sec) * 1000 + ms - off, text)
            }
        }
        return out.sortedBy { it.ms }
    }
}

/** Mengambil lirik tersinkron dari LRCLIB (gratis, tanpa API key) + cache lokal. */
object Lrclib {
    private const val API = "https://lrclib.net/api"
    private val clean = Regex("""\s*[(\[][^)\]]*[)\]]|\s+-\s+(remaster|live|single|radio|version|official).*""", RegexOption.IGNORE_CASE)

    fun fetch(ctx: Context, t: Track): List<LrcLine>? {
        val title = clean.replace(t.title, "").trim().ifEmpty { t.title }
        val artist = t.artist.split(",", "&", " feat").first().trim()

        val dir = File(ctx.cacheDir, "lrc").apply { mkdirs() }
        val f = File(dir, UUID.nameUUIDFromBytes("$artist|$title".toByteArray()).toString() + ".lrc")
        if (f.exists()) return LrcParser.parse(f.readText())

        val q = { s: String -> URLEncoder.encode(s, "UTF-8") }
        var synced = ""

        val dur = t.durationMs / 1000
        val getUrl = buildString {
            append("$API/get?track_name=${q(title)}&artist_name=${q(artist)}")
            if (t.album.isNotBlank()) append("&album_name=${q(t.album)}")
            if (dur > 0) append("&duration=$dur")
        }
        http(getUrl)?.let { synced = synced(JSONObject(it)) }

        if (synced.isEmpty()) {
            http("$API/search?track_name=${q(title)}&artist_name=${q(artist)}")?.let { synced = firstSynced(JSONArray(it)) }
        }
        if (synced.isEmpty()) {
            http("$API/search?q=${q("$title $artist")}")?.let { synced = firstSynced(JSONArray(it)) }
        }
        if (synced.isEmpty()) return null
        f.writeText(synced)
        return LrcParser.parse(synced)
    }

    private fun synced(o: JSONObject) = if (o.isNull("syncedLyrics")) "" else o.getString("syncedLyrics")

    private fun firstSynced(a: JSONArray): String {
        for (i in 0 until a.length()) { val s = synced(a.getJSONObject(i)); if (s.isNotEmpty()) return s }
        return ""
    }

    private fun http(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = 8000; c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "LyricsPlusBedrock/1.0")
            if (c.responseCode == 200) c.inputStream.bufferedReader().readText() else null
        } catch (_: Exception) { null } finally { c.disconnect() }
    }
}
