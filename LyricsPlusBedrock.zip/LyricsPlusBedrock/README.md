# LyricsPlus Bedrock (companion overlay)

Versi Android dari fungsi mod LyricsPlus (Fabric 1.20.1) untuk dipakai bersama Minecraft Bedrock.
Bukan mod yang disuntik ke game: ini aplikasi overlay terpisah yang tampil di atas Minecraft.

## Build
1. Buka folder ini di Android Studio (Hedgehog atau lebih baru), tunggu Gradle sync.
2. Build > Build APK(s). Install APK di HP.
3. Buka app > beri izin overlay + akses notifikasi > Mulai overlay > buka Minecraft.

## Fitur
- Bulatan wajah pixel (bisa diseret). Ketuk = menu: lirik on/off, mini player, baris berikutnya,
  mode ringkas, ukuran teks, transparansi, posisi, offset sinkron, prev/play/next.
- Membaca lagu dari aplikasi musik APA PUN yang memakai MediaSession (Spotify, YT Music, pemutar bawaan, dll).
- Lirik tersinkron dari LRCLIB (butuh internet), di-cache lokal.

## Asal logika
Diport dari kelas mod asli: LrclibClient (lrclib.net/api/get + fallback search), LrcParser (regex timestamp + offset),
TrackInfo (estimasi posisi), LyricsConfig (opsi on/off). Bagian Windows media session & bridge HTTP diganti
MediaListener (Android).
