package com.lyricsplus.bedrock

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.*
import android.widget.*
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.min

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private lateinit var bubble: SteveFaceView
    private lateinit var bubbleP: WindowManager.LayoutParams
    private lateinit var menu: ScrollView
    private lateinit var menuP: WindowManager.LayoutParams
    private lateinit var lyricsBox: LinearLayout
    private lateinit var lyricsP: WindowManager.LayoutParams
    private lateinit var tvPrev: TextView
    private lateinit var tvCur: TextView
    private lateinit var tvNext: TextView
    private lateinit var playerBox: LinearLayout
    private lateinit var tvTitle: TextView
    private lateinit var bar: ProgressBar
    private var menuShown = false

    @Volatile private var lines: List<LrcLine>? = null
    @Volatile private var loadedKey = ""

    private val tick = object : Runnable {
        override fun run() { update(); h.postDelayed(this, 120) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startFg()
        buildLyrics(); buildPlayer(); buildMenu(); buildBubble()
        running = true
        h.post(tick)
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        listOf<View>(bubble, menu, lyricsBox, playerBox).forEach { try { wm.removeView(it) } catch (_: Exception) {} }
        io.shutdownNow()
        running = false
        super.onDestroy()
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, hgt: Int, touch: Boolean): WindowManager.LayoutParams {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        if (!touch) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(w, hgt, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, f, PixelFormat.TRANSLUCENT)
    }

    private fun bg(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radiusDp).toFloat()
    }

    private fun screen(): DisplayMetrics {
        val dm = DisplayMetrics(); @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm); return dm
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("lp", "LyricsPlus", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "lp")
            .setContentTitle("LyricsPlus aktif")
            .setContentText("Overlay lirik sedang berjalan")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        startForeground(1, n)
    }

    // ---------- lyrics overlay ----------
    private fun buildLyrics() {
        lyricsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = bg(0x99000000.toInt(), 12)
        }
        fun tv() = TextView(this).apply { gravity = Gravity.CENTER; setTextColor(Color.WHITE); setShadowLayer(4f, 0f, 0f, Color.BLACK) }
        tvPrev = tv(); tvCur = tv().apply { setTypeface(typeface, Typeface.BOLD); setTextColor(0xFF55FF55.toInt()) }; tvNext = tv()
        lyricsBox.addView(tvPrev); lyricsBox.addView(tvCur); lyricsBox.addView(tvNext)
        lyricsP = lp((screen().widthPixels * 0.7).toInt(), WindowManager.LayoutParams.WRAP_CONTENT, false).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(Prefs.lyricsY)
        }
        wm.addView(lyricsBox, lyricsP)
    }

    // ---------- mini player ----------
    private fun buildPlayer() {
        playerBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = bg(0x99000000.toInt(), 10)
        }
        tvTitle = TextView(this).apply { setTextColor(Color.WHITE); textSize = 12f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
        playerBox.addView(tvTitle); playerBox.addView(bar, LinearLayout.LayoutParams(-1, dp(6)))
        val p = lp(dp(190), WindowManager.LayoutParams.WRAP_CONTENT, false).apply {
            gravity = Gravity.TOP or Gravity.END; x = dp(12); y = dp(12)
        }
        wm.addView(playerBox, p)
    }

    // ---------- floating bubble ----------
    private fun buildBubble() {
        bubble = SteveFaceView(this)
        bubbleP = lp(dp(48), dp(48), true).apply { gravity = Gravity.TOP or Gravity.START; x = Prefs.bx; y = Prefs.by }
        bubble.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = bubbleP.x; sy = bubbleP.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        if (moved) { bubbleP.x = sx + dx; bubbleP.y = sy + dy; wm.updateViewLayout(v, bubbleP); if (menuShown) positionMenu() }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) toggleMenu() else { Prefs.bx = bubbleP.x; Prefs.by = bubbleP.y }
                }
                return true
            }
        })
        wm.addView(bubble, bubbleP)
    }

    // ---------- mod menu ----------
    private fun buildMenu() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)) }
        menu = ScrollView(this).apply { background = bg(0xEE1E1E1E.toInt(), 14); addView(col) }

        col.addView(TextView(this).apply { text = "LyricsPlus"; textSize = 16f; setTextColor(0xFF55FF55.toInt()); setTypeface(typeface, Typeface.BOLD) })

        fun sw(label: String, get: () -> Boolean, set: (Boolean) -> Unit) {
            col.addView(Switch(this).apply {
                text = label; setTextColor(Color.WHITE); isChecked = get()
                setOnCheckedChangeListener { _, v -> set(v); applyStyle() }
            })
        }
        fun seek(label: String, lo: Int, hi: Int, get: () -> Int, set: (Int) -> Unit, fmt: (Int) -> String) {
            val t = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 12f; text = label + ": " + fmt(get()) }
            val s = SeekBar(this).apply {
                max = hi - lo; progress = get() - lo
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                        if (!fromUser) return
                        set(p + lo); t.text = label + ": " + fmt(p + lo); applyStyle()
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }
            col.addView(t); col.addView(s)
        }

        sw("Tampilkan lirik", { Prefs.lyricsOn }, { Prefs.lyricsOn = it })
        sw("Mini player", { Prefs.playerOn }, { Prefs.playerOn = it })
        sw("Baris berikutnya", { Prefs.nextLine }, { Prefs.nextLine = it })
        sw("Mode ringkas (1 baris)", { Prefs.compact }, { Prefs.compact = it })
        seek("Ukuran teks", 12, 32, { Prefs.textSize }, { Prefs.textSize = it }) { "$it" }
        seek("Transparansi", 20, 100, { Prefs.alpha }, { Prefs.alpha = it }) { "$it%" }
        seek("Posisi lirik (vertikal)", 0, 300, { Prefs.lyricsY }, { Prefs.lyricsY = it }) { "$it" }
        seek("Offset sinkron", -3000, 3000, { Prefs.offsetMs }, { Prefs.offsetMs = (it / 100) * 100 }) { "${it} ms" }

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun btn(txt: String, act: () -> Unit) = Button(this).apply { text = txt; setOnClickListener { act() } }
        row.addView(btn("⏮") { MediaState.controller?.transportControls?.skipToPrevious() })
        row.addView(btn("⏯") {
            val tc = MediaState.controller?.transportControls
            if (MediaState.playing) tc?.pause() else tc?.play()
        })
        row.addView(btn("⏭") { MediaState.controller?.transportControls?.skipToNext() })
        col.addView(row)
        col.addView(Button(this).apply { text = "Tutup overlay"; setOnClickListener { stopSelf() } })

        menuP = lp(dp(270), dp(10), true).apply { gravity = Gravity.TOP or Gravity.START }
        menu.visibility = View.GONE
        wm.addView(menu, menuP)
    }

    private fun toggleMenu() {
        menuShown = !menuShown
        menu.visibility = if (menuShown) View.VISIBLE else View.GONE
        if (menuShown) positionMenu()
    }

    private fun positionMenu() {
        val dm = screen()
        menuP.height = (dm.heightPixels * 0.75).toInt()
        menuP.x = min(bubbleP.x + dp(56), dm.widthPixels - dp(280)).coerceAtLeast(dp(4))
        menuP.y = bubbleP.y.coerceIn(0, dm.heightPixels / 8)
        wm.updateViewLayout(menu, menuP)
    }

    // ---------- rendering ----------
    private fun applyStyle() {
        val a = Prefs.alpha / 100f
        lyricsBox.alpha = a; playerBox.alpha = a
        val s = Prefs.textSize.toFloat()
        tvCur.textSize = s; tvPrev.textSize = s * 0.7f; tvNext.textSize = s * 0.7f
        tvPrev.alpha = 0.6f; tvNext.alpha = 0.6f
        lyricsP.y = dp(Prefs.lyricsY)
        try { wm.updateViewLayout(lyricsBox, lyricsP) } catch (_: Exception) {}
    }

    private fun setLines(prev: String, cur: String, next: String) {
        fun TextView.set(s: String) { text = s; visibility = if (s.isEmpty()) View.GONE else View.VISIBLE }
        tvPrev.set(prev); tvCur.set(cur); tvNext.set(next)
    }

    private fun update() {
        val t = MediaState.track
        playerBox.visibility = if (Prefs.playerOn && t != null) View.VISIBLE else View.GONE
        if (t == null) { lyricsBox.visibility = View.GONE; return }

        val pos = MediaState.currentPos()
        tvTitle.text = (if (MediaState.playing) "▶ " else "⏸ ") + t.title + " — " + t.artist
        if (t.durationMs > 0) bar.progress = (pos * 1000 / t.durationMs).toInt().coerceIn(0, 1000)

        if (!Prefs.lyricsOn) { lyricsBox.visibility = View.GONE; return }
        applyStyleOnce()

        if (t.key != loadedKey) {
            val key = t.key
            loadedKey = key; lines = null
            io.execute {
                val r = try { Lrclib.fetch(this, t) } catch (_: Exception) { null } ?: emptyList()
                if (loadedKey == key) lines = r
            }
        }

        lyricsBox.visibility = View.VISIBLE
        val ls = lines
        when {
            ls == null -> setLines("", "Mencari lirik…", "")
            ls.isEmpty() -> setLines("", "♪ " + t.title, "Lirik tidak ditemukan")
            else -> {
                val p = pos + Prefs.offsetMs
                val i = ls.indexOfLast { it.ms <= p }
                val cur = if (i < 0) "♪" else ls[i].text.ifEmpty { "♪" }
                val prev = if (!Prefs.compact && i > 0) ls[i - 1].text else ""
                val next = if (!Prefs.compact && Prefs.nextLine && i + 1 < ls.size) ls[i + 1].text else ""
                setLines(prev, cur, next)
            }
        }
    }

    private var styled = false
    private fun applyStyleOnce() { if (!styled) { styled = true; applyStyle() } }

    companion object { @Volatile var running = false }
}
