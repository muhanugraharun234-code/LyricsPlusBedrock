package com.lyricsplus.bedrock

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("lp", 0) }

    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun i(k: String, d: Int) = sp.getInt(k, d)

    var lyricsOn: Boolean get() = b("lyricsOn", true); set(v) { sp.edit().putBoolean("lyricsOn", v).apply() }
    var playerOn: Boolean get() = b("playerOn", true); set(v) { sp.edit().putBoolean("playerOn", v).apply() }
    var nextLine: Boolean get() = b("nextLine", true); set(v) { sp.edit().putBoolean("nextLine", v).apply() }
    var compact: Boolean get() = b("compact", false); set(v) { sp.edit().putBoolean("compact", v).apply() }
    var textSize: Int get() = i("textSize", 18); set(v) { sp.edit().putInt("textSize", v).apply() }
    var alpha: Int get() = i("alpha", 90); set(v) { sp.edit().putInt("alpha", v).apply() }
    var offsetMs: Int get() = i("offsetMs", 0); set(v) { sp.edit().putInt("offsetMs", v).apply() }
    var lyricsY: Int get() = i("lyricsY", 24); set(v) { sp.edit().putInt("lyricsY", v).apply() }
    var bx: Int get() = i("bx", 16); set(v) { sp.edit().putInt("bx", v).apply() }
    var by: Int get() = i("by", 120); set(v) { sp.edit().putInt("by", v).apply() }
}
