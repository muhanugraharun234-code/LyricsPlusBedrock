package com.lyricsplus.bedrock

import android.content.Context
import android.graphics.*
import android.view.View

/** Tombol bulat bergambar wajah pixel ala karakter blok. Ganti dengan drawable sendiri jika mau. */
class SteveFaceView(c: Context) : View(c) {
    private val grid = arrayOf(
        "HHHHHHHH",
        "HHHHHHHH",
        "HSSSSSSH",
        "SSSSSSSS",
        "SEBSSBES",
        "SSSNNSSS",
        "SSMMMMSS",
        "SSMSSMSS"
    )
    private val colors = mapOf(
        'H' to 0xFF4A2E17.toInt(), 'S' to 0xFFC08A63.toInt(), 'E' to 0xFFFFFFFF.toInt(),
        'B' to 0xFF3B2F8F.toInt(), 'N' to 0xFF8A5A3C.toInt(), 'M' to 0xFF6B3F2A.toInt()
    )
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF55FF55.toInt() }
    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height).toFloat()
        val r = s / 2f
        path.reset(); path.addCircle(r, r, r, Path.Direction.CW)
        canvas.save(); canvas.clipPath(path)
        val cell = s / 8f
        p.style = Paint.Style.FILL
        for (y in 0 until 8) for (x in 0 until 8) {
            p.color = colors[grid[y][x]] ?: Color.MAGENTA
            canvas.drawRect(x * cell, y * cell, (x + 1) * cell + 1, (y + 1) * cell + 1, p)
        }
        canvas.restore()
        ring.strokeWidth = s * 0.06f
        canvas.drawCircle(r, r, r - ring.strokeWidth / 2, ring)
    }
}
