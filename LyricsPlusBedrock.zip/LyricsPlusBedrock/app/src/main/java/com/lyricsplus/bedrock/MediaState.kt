package com.lyricsplus.bedrock

import android.media.session.MediaController
import android.os.SystemClock

data class Track(val title: String, val artist: String, val album: String, val durationMs: Long) {
    val key get() = "$title|$artist"
}

object MediaState {
    @Volatile var track: Track? = null
    @Volatile var playing = false
    @Volatile var posMs = 0L
    @Volatile var posTime = 0L
    @Volatile var speed = 1f
    @Volatile var controller: MediaController? = null

    fun currentPos(): Long =
        if (playing) posMs + ((SystemClock.elapsedRealtime() - posTime) * speed).toLong() else posMs
}
