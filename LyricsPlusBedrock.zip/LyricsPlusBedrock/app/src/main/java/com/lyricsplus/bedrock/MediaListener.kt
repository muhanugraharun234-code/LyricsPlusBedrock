package com.lyricsplus.bedrock

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService

/**
 * Membaca semua sesi media aktif di HP (aplikasi musik apa pun yang memakai MediaSession:
 * Spotify, YouTube Music, Samsung Music, Mi Music, Poweramp, dsb).
 * Butuh izin "Akses notifikasi".
 */
class MediaListener : NotificationListenerService() {

    private var msm: MediaSessionManager? = null
    private var controllers: List<MediaController> = emptyList()
    private val cn by lazy { ComponentName(this, MediaListener::class.java) }

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = pick()
        override fun onPlaybackStateChanged(state: PlaybackState?) = pick()
        override fun onSessionDestroyed() = refresh()
    }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> setControllers(list ?: emptyList()) }

    override fun onListenerConnected() {
        msm = getSystemService(MediaSessionManager::class.java)
        try { msm?.addOnActiveSessionsChangedListener(sessionsListener, cn) } catch (_: Exception) {}
        refresh()
    }

    override fun onListenerDisconnected() {
        try { msm?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Exception) {}
        controllers.forEach { try { it.unregisterCallback(cb) } catch (_: Exception) {} }
    }

    private fun refresh() {
        val list = try { msm?.getActiveSessions(cn) } catch (_: SecurityException) { null }
        setControllers(list ?: emptyList())
    }

    private fun setControllers(list: List<MediaController>) {
        controllers.forEach { try { it.unregisterCallback(cb) } catch (_: Exception) {} }
        controllers = list
        controllers.forEach { it.registerCallback(cb) }
        pick()
    }

    private fun pick() {
        val c = controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: controllers.firstOrNull { it.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) != null }
        if (c == null) {
            MediaState.track = null; MediaState.playing = false; MediaState.controller = null
            return
        }
        val m = c.metadata
        val ps = c.playbackState
        val title = m?.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty()
        if (title.isBlank()) { MediaState.track = null; return }
        val artist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val album = m?.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
        val dur = m?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L

        MediaState.controller = c
        MediaState.posMs = ps?.position ?: 0L
        MediaState.posTime = ps?.lastPositionUpdateTime ?: android.os.SystemClock.elapsedRealtime()
        MediaState.speed = ps?.playbackSpeed ?: 1f
        MediaState.playing = ps?.state == PlaybackState.STATE_PLAYING
        MediaState.track = Track(title, artist, album, dur)
    }
}
