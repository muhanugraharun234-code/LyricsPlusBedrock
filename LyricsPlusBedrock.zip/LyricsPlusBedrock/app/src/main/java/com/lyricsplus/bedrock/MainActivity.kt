package com.lyricsplus.bedrock

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.init(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }

        col.addView(TextView(this).apply { text = "LyricsPlus untuk Minecraft Bedrock"; textSize = 20f })
        col.addView(TextView(this).apply {
            text = "1) Beri izin overlay\n2) Beri akses notifikasi (agar bisa membaca lagu dari semua aplikasi musik)\n" +
                    "3) Mulai overlay, lalu buka Minecraft. Bulatan wajah muncul di layar — ketuk untuk membuka menu."
        })
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }

        col.addView(btn("1. Izin tampil di atas aplikasi lain") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("2. Izin akses notifikasi / media") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        })
        col.addView(btn("3. Mulai overlay") {
            if (!Settings.canDrawOverlays(this)) toast("Izin overlay belum diberikan")
            else startForegroundService(Intent(this, OverlayService::class.java))
        })
        col.addView(btn("Hentikan overlay") { stopService(Intent(this, OverlayService::class.java)) })
        col.addView(btn("Buka Minecraft") {
            val i = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
            if (i != null) startActivity(i) else toast("Minecraft Bedrock tidak ditemukan")
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
